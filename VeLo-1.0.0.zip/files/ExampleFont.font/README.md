# Example Font Folder

Add your font files here (.otf, .ttf, .woff, .woff2).

The folder name (minus the .font suffix) will be used as the display name.
